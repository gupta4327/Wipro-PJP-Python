perhour = 0.51
print("Question 1 -- How much does it cost to operate one server per day?")
print("Answer -- ",perhour*24,end="\n\n")
print("Question 2 -- How much does it cost to operate one server per week?")
print("Answer -- ",perhour*24*7,end="\n\n")
print("Question 3 -- How much does it cost to operate one server per month?")
print("Answer -- ",perhour*24*7*30,end="\n\n")
print("Question 1 -- How much days can i operate one server with 918 ?")
print("Answer -- ",918/(perhour*24),end="\n\n")
