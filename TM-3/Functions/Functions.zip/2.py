def revString(string):
    return string[::-1]

str = input("Enter a string: ")
print("Reversed string is: "+revString(str))    
